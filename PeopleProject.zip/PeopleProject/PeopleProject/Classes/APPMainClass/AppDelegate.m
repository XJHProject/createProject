//
//  AppDelegate.m
//  PeopleProject
//
//  Created by 熊进辉 on 2018/2/22.
//  Copyright © 2018年 熊进辉. All rights reserved.
//
/**
 1.导入第三方库
 2.构建项目框架
*/



#import "AppDelegate.h"
#import "OpenGLView.h"
#import "BaseTabBarController.h"


@interface AppDelegate ()

@end

@implementation AppDelegate
/*
 ／／每次点击item都会调用这个代理
 
 我们可以通过UITabBarControllerDelegate监听UITabBarController的选中的viewController的变化，以及moreViewController中对所有viewController的编辑。这里需要注意的是delegate方法要放在AppDelegate.h头文件里面。而且tabController.delegate要设置为self才会调用设置的方法。
 */
-(BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController{
    
    if ([BaseDataManager singleton].loginState==NO&&[tabBarController.viewControllers indexOfObject:viewController]==2) {

        [BaseDataManager singleton].loginState=NO;
         return NO;
    }
    [BaseDataManager singleton].selectIndex = [tabBarController.viewControllers indexOfObject:viewController];
    MYLog(@"select pick");
    return YES;
}
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [self setRootWindowWithIndex:0];
    [self monitorLoginState];
    return YES;
}
//监听[BaseDataManager singleton].loginState登录状态
-(void)monitorLoginState{
    [[BaseDataManager singleton] addObserver:self forKeyPath:@"loginState" options:(NSKeyValueObservingOptionNew) context:NULL];
}
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{
    if ([keyPath isEqualToString:@"loginState"]) {
        if (![BaseDataManager singleton].loginState) {
             [[BaseManager singleton] setRootToLoginViewController];
        }
    }
}
//设置rootController
-(void)setRootWindowWithIndex:(NSUInteger const)index{
    self.window  = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    BaseTabBarController * tbc=  [[BaseManager singleton] setRootControllerWithIndex:index];
    tbc.delegate=self;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end

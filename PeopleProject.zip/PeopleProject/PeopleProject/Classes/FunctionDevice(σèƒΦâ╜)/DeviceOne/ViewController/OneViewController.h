//
//  OneViewController.h
//  PeopleProject
//
//  Created by 熊进辉 on 2018/2/22.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import "BaseViewController.h"

@interface OneViewController : BaseViewController

@end

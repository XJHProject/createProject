//
//  OneViewController.m
//  PeopleProject
//
//  Created by 熊进辉 on 2018/2/22.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import "OneViewController.h"

#import "OenInfoViewController.h"



@interface OneViewController ()

@end

@implementation OneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setControllerTitle:@"one"];
    self.view.backgroundColor = [UIColor redColor];
    [self setUI];
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //隐藏navigationbar,
    //YES:有动画
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    //其他控制器显示navigationbar,
    //YES:有动画
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}
-(void)setUI{
    UIButton * button = [UIButton buttonWithType:(UIButtonTypeCustom)];
    [self.view addSubview:button];

    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view).mas_offset(20);
        make.top.equalTo(self.view).mas_offset(80);
        make.width.equalTo(self.view).mas_offset(100);
        make.height.equalTo(self.view).mas_offset(30);
    }];
//    button.frame = CGRectMake(30,50, 100, 30);
    [button setTitle:@"OpenGL" forState:(UIControlStateNormal)];
    [button setTitleColor:[UIColor blueColor] forState:(UIControlStateNormal)];
    [button setTitleColor:[UIColor blackColor] forState:(UIControlStateHighlighted)];
    button.titleLabel.font = [UIFont systemFontOfSize:15];
    @weakify(self);
    [button bk_addEventHandler:^(id sender) {
        @strongify(self);
        OenInfoViewController * vc =[[OenInfoViewController alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
    } forControlEvents:(UIControlEventTouchUpInside)];
    MYLog(@"hello world %@",configuration);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

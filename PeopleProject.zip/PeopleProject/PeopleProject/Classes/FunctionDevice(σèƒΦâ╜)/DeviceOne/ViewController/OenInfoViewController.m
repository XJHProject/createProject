//
//  OenInfoViewController.m
//  PeopleProject
//
//  Created by 熊进辉 on 2018/2/22.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import "OenInfoViewController.h"
#import "OpenGLView.h"

@interface OenInfoViewController ()

@end

@implementation OenInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor whiteColor];
    OpenGLView * openView=[[OpenGLView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    openView.backgroundColor=[UIColor redColor];
//    [BaseDataManager singleton].loginState=NO;
    [self.view addSubview:openView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

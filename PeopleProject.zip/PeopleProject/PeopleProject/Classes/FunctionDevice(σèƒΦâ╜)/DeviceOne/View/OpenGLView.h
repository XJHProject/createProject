//
//  OpenGLView.h
//  PeopleProject
//
//  Created by 熊进辉 on 2018/3/7.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <OpenGLES/ES2/gl.h>
#import <OpenGLES/ES2/glext.h>

@interface OpenGLView : UIView

{
    CAEAGLLayer * _eaglLayer;
    EAGLContext * _context;
    GLuint _colorRenderBuffer;
}
@end

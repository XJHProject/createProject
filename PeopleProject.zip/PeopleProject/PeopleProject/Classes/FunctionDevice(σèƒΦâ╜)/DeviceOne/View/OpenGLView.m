//
//  OpenGLView.m
//  PeopleProject
//
//  Created by 熊进辉 on 2018/3/7.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import "OpenGLView.h"

@implementation OpenGLView
//想要显示OpenGL的内容，你需要把它缺省的layer设置为一个特殊的layer（CAEAGLLayer）,这里通过直接复写layerClass方法
-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self setupLayer];
        [self setupContext];
        [self setupRenderBuffer];
        [self setupFrameBuffer];
        [self render];
    }
    return self;
}
+(Class)layerClass{
    return [CAEAGLLayer class];
}
//设置layer为不透明
//因为缺省的话，CALayer是透明的，而透明的层对性能负荷很大，特别是OpenGL的层
-(void)setupLayer{
    _eaglLayer = (CAEAGLLayer *)self.layer;
    _eaglLayer.opaque=YES;
}
//创建OpenGL context
-(void)setupContext{
    //创建Context，需要声明使用那个version的API
    EAGLRenderingAPI api = kEAGLRenderingAPIOpenGLES2;
    //无论你需要OpenGL实现什么，都需要EAGLContext
    //EAGLContext管理所有通过OpenGL的绘画
    _context = [[EAGLContext alloc] initWithAPI:api];
    if (!_context) {
        //创建失败退出
        MYLog(@"Failed to initialize OpenGLES 2.0 context");
        exit(1);
    }
    if (![EAGLContext setCurrentContext:_context]) {
        //创建失败退出
        MYLog(@"Failed to set current OpenGL context");
        exit(1);
    }
}
//Render buffer是OpenGL的一个对象，用于存放渲染过的图像
-(void)setupRenderBuffer{
    //glGenRenderbuffers：创建新的Render buffer对象
    //1(integer）:标记render buffer,唯一性可作为OpenGL的名称
    glGenRenderbuffers(1, &_colorRenderBuffer);
    //glBindRenderbuffer：定义buffer对象是属于GL_RENDERBUFFER类型
    glBindRenderbuffer(GL_RENDERBUFFER, _colorRenderBuffer);
    //为render buffer分配空间
    [_context renderbufferStorage:GL_RENDERBUFFER fromDrawable:_eaglLayer];
}
//创建一个frame buffer(帧缓冲区)
-(void)setupFrameBuffer{
    GLuint framebuffer;
    glGenRenderbuffers(1, &framebuffer);
    glBindRenderbuffer(GL_FRAMEBUFFER, framebuffer);
    //把_colorRenderBuffer依附在frame buffer的GL_COLOR_ATTACHMENT0上
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_RENDERBUFFER, _colorRenderBuffer);
}
//清理屏幕
-(void)render{
    //设置填充颜色
    glClearColor(0.0, 104.0/255.0, 55.0/255.0, 0.6);
    //用上面颜色填充
    //GL_COLOR_BUFFER_BIT:声明清理的缓冲区
    glClear(GL_COLOR_BUFFER_BIT);
    //把缓冲区的颜色呈现在UIView上
    [_context presentRenderbuffer:GL_RENDERBUFFER];
}
-(void)dealloc{
    _context=nil;
}
@end

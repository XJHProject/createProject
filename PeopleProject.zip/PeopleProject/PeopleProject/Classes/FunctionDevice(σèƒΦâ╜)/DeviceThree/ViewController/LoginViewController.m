//
//  LoginViewController.m
//  PeopleProject
//
//  Created by 熊进辉 on 2018/3/13.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import "LoginViewController.h"
#import "AppDelegate.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor=[UIColor yellowColor];
    self.title = @"登录";
    //self.title上面的小标题,navigationItem的高加30
//    self.navigationItem.prompt=@"login";
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"icon_back_normal"] style:(UIBarButtonItemStylePlain) target:self action:@selector(backTabBarRootWindow)];
    
    //UINavigationController自带了一个工具栏
    [self.navigationController setToolbarHidden:NO];
    UIBarButtonItem * one = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:(UIBarButtonSystemItemAdd) target:nil action:nil];
    UIBarButtonItem * two = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:(UIBarButtonSystemItemSave) target:nil action:nil];
    UIBarButtonItem * three = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:(UIBarButtonSystemItemAction) target:nil action:nil];
    UIBarButtonItem * four = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:(UIBarButtonSystemItemSearch) target:nil action:nil];
    UIBarButtonItem * fixed = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:(UIBarButtonSystemItemFlexibleSpace) target:nil action:nil];
    self.toolbarItems = @[one,fixed,two,fixed,three,fixed,four];
    
}
-(void)backTabBarRootWindow{
    [BaseDataManager singleton].loginState = YES;
    if ([BaseDataManager singleton].loginState) {
        [BaseDataManager singleton].selectIndex=2;
    }
    AppDelegate * del = (AppDelegate *)[UIApplication sharedApplication].delegate;
    [del setRootWindowWithIndex:[BaseDataManager singleton].selectIndex];
    //
//    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

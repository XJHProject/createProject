//
//  AnimationViewController.m
//  PeopleProject
//
//  Created by 熊进辉 on 2018/3/20.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import "AnimationViewController.h"


@interface AnimationViewController ()
@property (nonatomic, strong) UIView * animationView;
@property (nonatomic, strong) UIButton * animationButton;
@property (nonatomic, strong) UIButton * oneButton;
@property (nonatomic, strong) UIButton * twoButton;
@property (nonatomic, strong) UIButton * threeButton;

@end

@implementation AnimationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
//    [self layoutAnimationView];
    [self setButton];
}


-(void)setButton{
    UIButton * button =[UIButton buttonWithType:(UIButtonTypeCustom)];
    self.animationButton = button;
    [button setTitle:@"开始动画" forState:(UIControlStateNormal)];
    [button setTitleColor:[UIColor redColor] forState:(UIControlStateNormal)];
    button.titleLabel.font = [UIFont systemFontOfSize:16];
    [self.view addSubview:button];
    button.backgroundColor=[UIColor blueColor];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.view).offset(-20);
        make.centerX.equalTo(self.view);
        make.height.mas_equalTo(30);
        make.width.mas_equalTo(100);
    }];
    [button bk_addEventHandler:^(id sender) {
//        [self setBasic];//基础动画
//        [self setKeyFrame];//关键帧动画
//        [self setGroup];//组动画
        [self customOneGroupAnimation];
        [self customTwoGroupAnimation];
        [self customThreeGroupAnimation];
    } forControlEvents:(UIControlEventTouchUpInside)];
}
-(void)customThreeGroupAnimation{
    if (self.threeButton) {
        [self.threeButton removeFromSuperview];
    }
    self.threeButton = [UIButton buttonWithType:(UIButtonTypeCustom)];
    self.threeButton.size = CGSizeMake(50, 50);
    self.threeButton.center = CGPointMake(250, 400);
    self.threeButton.backgroundColor=[UIColor blueColor];
    [self.view addSubview:self.threeButton];
    [self.threeButton bk_addEventHandler:^(id sender) {
        MYLog(@"threeButton");
    } forControlEvents:(UIControlEventTouchUpInside)];
    //
    CABasicAnimation * anima1 =[CABasicAnimation animationWithKeyPath:@"position"];
    anima1.fromValue = [NSValue valueWithCGPoint:self.animationButton.center];
    anima1.toValue = [NSValue valueWithCGPoint:CGPointMake(250, 400)];
    //
    CABasicAnimation * anima2 =[CABasicAnimation animationWithKeyPath:@"transform.rotation"];
    anima2.toValue = [NSNumber numberWithFloat:M_PI*4];
    //
    CABasicAnimation * anima3 = [CABasicAnimation animationWithKeyPath:@"opacity"];
    anima3.fromValue =[NSNumber numberWithFloat:0.0f];
    anima3.toValue = [NSNumber numberWithFloat:1.0f];
    //
    CABasicAnimation * anima4 = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    anima4.fromValue = [NSNumber numberWithFloat:0.3f];
    anima4.toValue = [NSNumber numberWithFloat:1.0f];
    //
    CAAnimationGroup * group = [CAAnimationGroup animation];
    group.animations = [NSArray arrayWithObjects:anima1,anima2,anima3,anima4, nil];
    group.duration =1.0f;
    group.fillMode = kCAFillModeBoth;
    group.removedOnCompletion = NO;
    [self.threeButton.layer addAnimation:group forKey:@"threeGroup"];
    
    
}
-(void)customTwoGroupAnimation{
    if (self.twoButton) {
        [self.twoButton removeFromSuperview];
    }
    self.twoButton = [UIButton buttonWithType:(UIButtonTypeCustom)];
    self.twoButton.size = CGSizeMake(50, 50);
    self.twoButton.center = CGPointMake(150, 400);
    self.twoButton.backgroundColor=[UIColor yellowColor];
    [self.view addSubview:self.twoButton];
    [self.twoButton bk_addEventHandler:^(id sender) {
        MYLog(@"twoButton");
    } forControlEvents:(UIControlEventTouchUpInside)];
    //位移
    CAKeyframeAnimation * anima1 = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    NSValue * fromValue = [NSValue valueWithCGPoint:self.animationButton.center];
    NSValue * onValue = [NSValue valueWithCGPoint:CGPointMake(self.animationButton.center.x-50, self.animationButton.y-50)];
    NSValue * toValue = [NSValue valueWithCGPoint:CGPointMake(150, 400)];
    anima1.values = [NSArray arrayWithObjects:fromValue,onValue,toValue, nil];
    //缩放
    CABasicAnimation * anima2 = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    anima2.fromValue = [NSNumber numberWithFloat:0.3f];
    anima2.toValue = [NSNumber numberWithFloat:1.0f];
    //透明度
    CABasicAnimation * anima3 = [CABasicAnimation animationWithKeyPath:@"opacity"];
    anima3.fromValue = [NSNumber numberWithFloat:0.0f];
    anima3.toValue = [NSNumber numberWithFloat:1.0f];
    //旋转
    CABasicAnimation * anima4 = [CABasicAnimation animationWithKeyPath:@"transform.rotation"];
    anima4.toValue = [NSNumber numberWithFloat:M_PI*4];
    //组动画
    CAAnimationGroup * group = [CAAnimationGroup animation];
    group.animations = [NSArray arrayWithObjects:anima1,anima2,anima3,anima4, nil];
    group.duration = 1.0f;
    group.fillMode = kCAFillModeBoth;
    group.removedOnCompletion = NO;
    [self.twoButton.layer addAnimation:group forKey:@"twoAnimation"];
    
}
-(void)customOneGroupAnimation{
    if (self.oneButton) {
        [self.oneButton removeFromSuperview];
    }
    self.oneButton =[UIButton buttonWithType:(UIButtonTypeCustom)];
    self.oneButton.backgroundColor = [UIColor redColor];
    [self.view addSubview:self.oneButton];
    self.oneButton.size = CGSizeMake(50, 50);
    self.oneButton.center = CGPointMake(50, 400);
    [self.oneButton bk_addEventHandler:^(id sender) {
        MYLog(@"oneButton");
        //one
        CABasicAnimation * animaOne1 = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
        animaOne1.fromValue = [NSNumber numberWithFloat:1.0f];
        animaOne1.toValue = [NSNumber numberWithFloat:1.5f];
        //颜色变化
        CABasicAnimation * animaOne2 = [CABasicAnimation animationWithKeyPath:@"backgroundColor"];
//        animaOne2.fromValue = [NSNumber numberWithFloat:1.0f];
//        animaOne2.toValue = [NSNumber numberWithFloat:0.0f];
        animaOne2.fromValue = (id)[UIColor greenColor].CGColor;
        animaOne2.toValue = (id)[UIColor blackColor].CGColor;
        //
        CAAnimationGroup * groupOne = [CAAnimationGroup animation];
        groupOne.duration = 2.0f;
        groupOne.fillMode = kCAFillModeBoth;
        groupOne.removedOnCompletion = NO;
        groupOne.animations = [NSArray arrayWithObjects:animaOne1,animaOne2, nil];
        [self.oneButton.layer addAnimation:groupOne forKey:@"groupOne"];
        //
        CABasicAnimation * twoBasic = [CABasicAnimation animationWithKeyPath:@"opacity"];
        twoBasic.fromValue = [NSNumber numberWithFloat:1.0f];
        twoBasic.toValue = [NSNumber numberWithFloat:0.0f];
        twoBasic.duration=2.0f;
        twoBasic.fillMode = kCAFillModeBoth;
        twoBasic.removedOnCompletion = NO;
        
        [self.twoButton.layer addAnimation:twoBasic forKey:@"two"];
        //
        [self.threeButton.layer addAnimation:twoBasic forKey:@"three"];
       
        self.twoButton.enabled=NO;
        self.threeButton.enabled =NO;
        
        
        
    } forControlEvents:(UIControlEventTouchUpInside)];
    //
    CAKeyframeAnimation * anima1 = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    NSValue *fromValue = [NSValue valueWithCGPoint:self.animationButton.center];
    NSValue *toValue = [NSValue valueWithCGPoint:CGPointMake(50, 400)];
    anima1.values = [NSArray arrayWithObjects:fromValue,toValue, nil];
    //
    CABasicAnimation * anima2= [CABasicAnimation animationWithKeyPath:@"transform.rotation"];
    anima2.toValue = [NSNumber numberWithFloat:M_PI*4];
    //
    CABasicAnimation * anima3 = [CABasicAnimation animationWithKeyPath:@"opacity"];
    anima3.fromValue = [NSNumber numberWithFloat:0.0f];
    anima3.toValue = [NSNumber numberWithFloat:1.0f];
    //
    CABasicAnimation * anima4 = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    anima4.fromValue = [NSNumber numberWithFloat:0.3f];
    anima4.toValue = [NSNumber numberWithFloat:1.0f];
    
    //
    CAAnimationGroup * group = [CAAnimationGroup animation];
    group.animations = [NSArray arrayWithObjects:anima1,anima2,anima3,anima4, nil];
    group.duration = 1.0f;
    group.fillMode = kCAFillModeBoth;
    group.removedOnCompletion = NO;
    [self.oneButton.layer addAnimation:group forKey:@"groupAnimation"];
    
}
//组动画
-(void)setGroup{
    //移动动画
    CAKeyframeAnimation * anima = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    NSValue * value0=[NSValue valueWithCGPoint:CGPointMake(20, 100)];
    NSValue * value1=[NSValue valueWithCGPoint:CGPointMake(100, 200)];
    NSValue * value2=[NSValue valueWithCGPoint:CGPointMake(200, 300)];
    NSValue * value3=[NSValue valueWithCGPoint:CGPointMake(300, 350)];
    NSValue * value4=[NSValue valueWithCGPoint:CGPointMake(200, 400)];
    NSValue * value5=[NSValue valueWithCGPoint:CGPointMake(100, 450)];
    anima.values = [NSArray arrayWithObjects:value0,value1,value2,value3,value4,value5, nil];
    //缩放动画
    CABasicAnimation * anima2 = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    anima2.fromValue = [NSNumber numberWithFloat:0.5f];
    anima2.toValue = [NSNumber numberWithFloat:2.0f];
    anima2.byValue = [NSNumber numberWithFloat:1.0f];

    //旋转动画
    CABasicAnimation * anima3 =[CABasicAnimation animationWithKeyPath:@"transform.rotation"];
    anima3.toValue = [NSNumber numberWithFloat:M_PI*4];
    //组动画
    CAAnimationGroup * group = [CAAnimationGroup animation];
    group.animations = [NSArray arrayWithObjects:anima,anima2,anima3, nil];
    group.duration = 5.0f;
    group.fillMode = kCAFillModeBoth;
    group.removedOnCompletion = NO;
    [self.animationView.layer addAnimation:group forKey:@"groupAnimation"];
    
}
//关键帧动画
-(void)setKeyFrame{
    CAKeyframeAnimation * keyFrame = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(100, 300, 350, 250)];
    keyFrame.path = path.CGPath;
    keyFrame.duration = 2.0f;
    [self.animationView.layer addAnimation:keyFrame forKey:@"pathAnimation"];
}
//基础动画
-(void)setBasic{
    CABasicAnimation * basic =[CABasicAnimation animationWithKeyPath:@"opacity"];
    //transform.rotation：旋转
    //transform.scale:缩放
    //position:平移
    //opacity:透明度
    //backgroundColor:背景颜色.CGColor
//    basic.fromValue = [NSValue valueWithCGPoint:CGPointMake(0, 300)];
//    basic.toValue = [NSValue valueWithCGPoint:CGPointMake(300, 300)];
    basic.fromValue = [NSNumber numberWithFloat:1.0f];
    basic.toValue = [NSNumber numberWithFloat:0.2f];
    basic.duration = 1.0;
    //如果fillMode=kCAFillModeForwards和removedOnComletion=NO，那么在动画执行完毕后，图层会保持显示动画执行后的状态。但在实质上，图层的属性值还是动画执行前的初始值，并没有真正被改变。
//    basic.fillMode = kCAFillModeBoth;
//    basic.removedOnCompletion = NO;
    [self.animationView.layer addAnimation:basic forKey:@"positionAnimation"];
}
-(void)layoutAnimationView{
    self.animationView = [[UIView alloc]init];
    self.animationView.backgroundColor = [UIColor redColor];
    [self.view addSubview:self.animationView];
    [self.animationView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.mas_offset(100);
        make.height.width.mas_equalTo(100);
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  AnimationViewController.h
//  PeopleProject
//
//  Created by 熊进辉 on 2018/3/20.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnimationViewController : UIViewController

@end

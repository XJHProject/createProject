//
//  GestureRecognizerViewController.m
//  PeopleProject
//
//  Created by 熊进辉 on 2018/3/20.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import "GestureRecognizerViewController.h"

@interface GestureRecognizerViewController ()
@property (nonatomic, strong) UIImageView * imageView;
@end

@implementation GestureRecognizerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor= [UIColor whiteColor];
    [self layoutImageView];
    [self setPan];//滑动手势
    [self setPinch];//捏合手势
    [self setRotation];//旋转手势
    [self setScreenEdgePan];//屏幕边缘平移手势
}
//屏幕边缘平移手势
-(void)setScreenEdgePan{
    UIScreenEdgePanGestureRecognizer * screenEdgePan = [[UIScreenEdgePanGestureRecognizer alloc]initWithTarget:self action:@selector(screenEdgePan:)];
    screenEdgePan.edges = UIRectEdgeAll;
    [self.imageView addGestureRecognizer:screenEdgePan];
}
-(void)screenEdgePan:(UIScreenEdgePanGestureRecognizer *)screenEdgePan{
    //计算偏移量
    CGPoint point = [screenEdgePan translationInView:self.imageView];
    //进行平移
    screenEdgePan.view.transform = CGAffineTransformMakeTranslation(point.x, point.y);
}
//旋转手势
-(void)setRotation{
    UIRotationGestureRecognizer * rotation = [[UIRotationGestureRecognizer alloc]initWithTarget:self action:@selector(rotationAction:)];
    [self.imageView addGestureRecognizer:rotation];
}
-(void)rotationAction:(UIRotationGestureRecognizer *)rotation{
    //以原来的位置为标准
    //    rotation.view.transform = CGAffineTransformMakeRotation(rotation.rotation);
    rotation.view.transform = CGAffineTransformRotate(rotation.view.transform, rotation.rotation);
    //消除增量
    rotation.rotation=0.0;
}
//捏合手势
-(void)setPinch{
    UIPinchGestureRecognizer * pinch = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(pinchAction:)];
    [self.imageView addGestureRecognizer:pinch];
    
}
-(void)pinchAction:(UIPinchGestureRecognizer *)pinch{
    //scale 缩放比例
    //    pinch.view.transform = CGAffineTransformMake(pinch.scale, 0, 0, pinch.scale, 0, 0);
    //每次缩放以原来位置为标准
    //    pinch.view.transform = CGAffineTransformMakeScale(pinch.scale, pinch.scale);
    //每次缩放以上一次为标准
    pinch.view.transform = CGAffineTransformScale(pinch.view.transform, pinch.scale, pinch.scale);
    //重新设置缩放比例 1是正常缩放.小于1时是缩小(无论何种操作都是缩小),大于1时是放大(无论何种操作都是放大)
    pinch.scale=1;
}
//滑动手势
-(void)setPan{
    UIPanGestureRecognizer * pan = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panAction:)];
    [self.imageView addGestureRecognizer:pan];
}
-(void)panAction:(UIPanGestureRecognizer *)pan{
    CGPoint point = [pan translationInView:self.imageView];
    pan.view.transform = CGAffineTransformTranslate(pan.view.transform, point.x, point.y);
    [pan setTranslation:CGPointZero inView:pan.view];//CGPointZero：随着手指滑动
    
}
//长按手势
-(void)setLongPress{
    UILongPressGestureRecognizer * longPress = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longPressAction:)];
    longPress.minimumPressDuration = 1;
    [self.imageView addGestureRecognizer:longPress];
}
-(void)longPressAction:(UILongPressGestureRecognizer *)longPress{
    if (longPress.state == UIGestureRecognizerStateBegan) {
        MYLog(@"began");
    }else if (longPress.state == UIGestureRecognizerStateChanged){
        MYLog(@"change");
    }else if (longPress.state == UIGestureRecognizerStateEnded){
        MYLog(@"end");
    }
}
//轻扫手势
-(void)setSwipe{
    UISwipeGestureRecognizer * swipe = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeAction:)];
    //设置手指数
    swipe.numberOfTouchesRequired = 1;
    //设置扫动方向
    swipe.direction = UISwipeGestureRecognizerDirectionLeft;//默认是right
    [self.imageView addGestureRecognizer:swipe];
}
-(void)swipeAction:(UISwipeGestureRecognizer *)swipe{
    if (swipe.direction == UISwipeGestureRecognizerDirectionLeft) {
        MYLog(@"Left");
    }else if (swipe.direction == UISwipeGestureRecognizerDirectionRight){
        MYLog(@"right");
    }else if (swipe.direction == UISwipeGestureRecognizerDirectionDown){
        MYLog(@"down");
    }else{
        MYLog(@"up");
    }
    @weakify(self);
    [UIView animateWithDuration:0.5 animations:^{
        @strongify(self);
        [self.imageView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.view).offset(200);
            make.width.height.mas_equalTo(150);
            make.left.equalTo(self.view).offset(100);
        }];
    }];
}
//点击手势
-(void)setTap{
    UITapGestureRecognizer * tap  =[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
    //设置点击次数
    tap.numberOfTapsRequired = 2;
    //设置手指数
    tap.numberOfTouchesRequired=1;
    [self.imageView addGestureRecognizer:tap];
}
-(void)tapAction:(UITapGestureRecognizer *)tap{
    CGFloat g = random()%2;
    if (g) {
        self.view.backgroundColor=[UIColor redColor];
    }else{
        self.view.backgroundColor=[UIColor greenColor];
    }
}
//imageview
-(void)layoutImageView{
    self.imageView = [[UIImageView alloc] init];
    [self.view addSubview:self.imageView];
    self.imageView.userInteractionEnabled=YES;
    self.imageView.image = [UIImage imageNamed:@"IMG_1591"];
    //
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.height.mas_equalTo(200);
        make.top.left.equalTo(self.view).offset(100);
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

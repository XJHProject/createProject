//
//  Student.m
//  PeopleProject
//
//  Created by 熊进辉 on 2018/3/22.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import "Student.h"

@implementation Student
+(void)load{
    
}
////动态方法
//void test(id self, SEL _cmd,id name){
//    MYLog(@"%@ will examination",name);
//}

//+(BOOL)resolveInstanceMethod:(SEL)sel{
//    if (sel == @selector(exam)) {
//        class_addMethod(self, sel, (IMP)test, "v@:@");
//        return  YES;
//    }
//    return [super resolveInstanceMethod:sel];
//}
//
//消息重定向
//该方法返回一个添加了方法实现的对象，
-(id)forwardingTargetForSelector:(SEL)aSelector{
    if(aSelector == @selector(trival)){
        School * s = [[School alloc]init];
        return s;
    }
    return [super forwardingTargetForSelector:aSelector];
}
//这个方法返回一个NSInvocation*的对象，里面打包了有关于这个未实现方法的信息
//-(void)trival{
//    MYLog(@"anything is not ok");
//}
-(NSMethodSignature *)methodSignatureForSelector:(SEL)aSelector{
    NSString * sel = NSStringFromSelector(aSelector);
    if ([sel isEqualToString:@"exam"]) {
        return [NSMethodSignature signatureWithObjCTypes:"v@:@"];
    }
    return [super methodSignatureForSelector:aSelector];
}
-(void)forwardInvocation:(NSInvocation *)anInvocation{
    SEL sel = @selector(exam:);
    NSMethodSignature * signature= [NSMethodSignature signatureWithObjCTypes:"v@:@"];
    anInvocation = [NSInvocation invocationWithMethodSignature:signature];
    [anInvocation setTarget:self];
    [anInvocation setSelector:sel];
    NSString * name = @"nothing action";
    [anInvocation setArgument:&name atIndex:2];
    if ([self respondsToSelector:sel]) {
        [anInvocation invokeWithTarget:self];
        return;
    }else{
        School * s = [[School alloc]init];
        if ([s respondsToSelector:sel]) {
            [anInvocation invokeWithTarget:s];
            return;
        }
    }

    [super forwardInvocation:anInvocation];
}

@end

//
//  School.m
//  PeopleProject
//
//  Created by 熊进辉 on 2018/3/22.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import "School.h"

@implementation School
-(void)exam:(NSString *)name{
    MYLog(@"%@ will examination on School",name);
}
-(void)trival{
    NSLog(@"Everything is ok");
}
@end

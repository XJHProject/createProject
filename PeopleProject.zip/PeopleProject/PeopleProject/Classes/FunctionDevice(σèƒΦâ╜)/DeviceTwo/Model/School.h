//
//  School.h
//  PeopleProject
//
//  Created by 熊进辉 on 2018/3/22.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface School : NSObject
-(void)exam:(NSString *)name;
-(void)trival;
@end

//
//  Student.h
//  PeopleProject
//
//  Created by 熊进辉 on 2018/3/22.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import "School.h"

@interface Student : NSObject
/*
 runtime消息转发机制
 1.根据isa指针找到对象所属的类或者类所属的元类
 2.先去类或者元类的Cache列表中根据SEL去找这个方法
 3.没有找到，去method方法列表中找
 4.还是没有找到，就去父类中找
 5.找到了，根据SEL找到对应的IMP,调用这个函数
 6.没有找到，进入动态方法解析或者消息转发
 */
-(void)exam:(NSString *)name;

@end

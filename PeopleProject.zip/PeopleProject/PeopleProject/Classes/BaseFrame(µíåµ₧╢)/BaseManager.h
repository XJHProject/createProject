//
//  BaseManager.h
//  PeopleProject
//
//  Created by 熊进辉 on 2018/2/22.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AppDelegate.h"
#import "BaseTabBarController.h"

//此单例类用于管理项目框架
@interface BaseManager : NSObject
+(instancetype)singleton;
//设置主窗口根控制器
-(BaseTabBarController *)setRootControllerWithIndex:(NSInteger)index;
//登录
-(void)setRootToLoginViewController;
@end

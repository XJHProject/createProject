//
//  BaseTabBarController.m
//  PeopleProject
//
//  Created by 熊进辉 on 2018/2/22.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import "BaseTabBarController.h"
#import "BaseNavigationController.h"
#import "OneViewController.h"
#import "TwoViewController.h"
#import "ThreeViewController.h"
#import "LoginViewController.h"

@interface BaseTabBarController ()<UITabBarDelegate,UITabBarControllerDelegate>

@end

@implementation BaseTabBarController
//修改tabbar的高度
-(void)viewWillLayoutSubviews{
    CGRect tabFrame = self.tabBar.frame;
    tabFrame.size.height=60;
    tabFrame.origin.y = self.view.bounds.size.height - 60;
    self.tabBar.frame=tabFrame;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initTabBar];
    //修改tabbar的背景色
//    UIView * view =[UIView new];
//    view.backgroundColor = [UIColor orangeColor];
//    view.frame = self.tabBar.bounds;
//    [[UITabBar appearance] insertSubview:view atIndex:0];
    //
    self.tabBar.barTintColor=[UIColor orangeColor];
    //这里设置tabBar的半透明属性translucent设置为NO，默认为YES,若保留半透明效果，设置的颜色会与正常的颜色有色差;
     self.tabBar.translucent=NO;
    //
//    [[UITabBar appearance] setBackgroundImage:[UIImage imageNamed:@"jb_mine_money"]];
//    self.tabBar.translucent=NO;
    //去除上部边框
    [[UITabBar appearance] setBackgroundImage:[UIImage new]];
    [[UITabBar appearance] setShadowImage:[UIImage new]];
    //
//    if (@available(iOS 10.0, *)) {
//        [UITabBar appearance].unselectedItemTintColor=[UIColor yellowColor];
//    } else {
//        // Fallback on earlier versions
//    }
//    [UITabBar appearance].tintColor= [UIColor redColor];
}
-(void)initTabBar{
    NSMutableArray * tabBarArray=[[NSMutableArray alloc]init];
    //one
    {
        OneViewController * oneVC=[[OneViewController alloc]init];
        BaseNavigationController * oneNav =[[BaseNavigationController alloc]initWithRootViewController:oneVC];
        
        //
        UIImage * oneNormalImage = [UIImage imageNamed:@"icon_home_normal"];
        oneNormalImage = [oneNormalImage imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)];
        UIImage * oneSelectImage = [UIImage imageNamed:@"icon_home_selected"];
        oneSelectImage = [oneSelectImage imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)];
        //
        oneNav.tabBarItem.image = oneNormalImage;
        oneNav.tabBarItem.selectedImage = oneSelectImage;
        oneNav.tabBarItem.imageInsets = UIEdgeInsetsMake(5, 0, -5, 0);
        //
        [tabBarArray addObject:oneNav];
    }
    //two
    {
        TwoViewController * twoVC=[[TwoViewController alloc]init];
        BaseNavigationController * twoNav =[[BaseNavigationController alloc]initWithRootViewController:twoVC];
        //
        UIImage * twoNormalImage = [UIImage imageNamed:@"icon_supermarket_normal"];
        twoNormalImage = [twoNormalImage imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)];
        UIImage * twoSelectImage = [UIImage imageNamed:@"icon_supermarket_selected"];
        twoSelectImage = [twoSelectImage imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)];
        //
        twoNav.tabBarItem.image=twoNormalImage;
        twoNav.tabBarItem.selectedImage = twoSelectImage;
        twoNav.tabBarItem.imageInsets = UIEdgeInsetsMake(5, 0, -5, 0);
        //
        [tabBarArray addObject:twoNav];
    }
    //three
    {
        ThreeViewController * threeVC = [[ThreeViewController alloc]init];
        BaseNavigationController * threeNav = [[BaseNavigationController alloc]initWithRootViewController:threeVC];
       
        //
        UIImage * threeNormalImage = [UIImage imageNamed:@"icon_news_normal"];
        threeNormalImage = [threeNormalImage imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)];
        UIImage * threeSelectImage = [UIImage imageNamed:@"icon_news__selected"];
        threeSelectImage = [threeSelectImage imageWithRenderingMode:(UIImageRenderingModeAlwaysOriginal)];
        //
        threeNav.tabBarItem.image=threeNormalImage;
        threeNav.tabBarItem.selectedImage = threeSelectImage;
        threeNav.tabBarItem.imageInsets = UIEdgeInsetsMake(5, 0, -5, 0);
        threeNav.tabBarItem.badgeValue=@"1";
        if (@available(iOS 10.0, *)) {
            threeNav.tabBarItem.badgeColor=[UIColor redColor];
        } else {
            // Fallback on earlier versions
        }
        //
         [tabBarArray addObject:threeNav];
    }
    //
    
    self.viewControllers = tabBarArray;
}
//UITabBarDelegate每次点击item都会调用这个代理
-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{
    MYLog(@"didSelect=%ld",[tabBar.items indexOfObject:item]);
    if ([tabBar.items indexOfObject:item]==2) {
//        LoginViewController * vc = [[LoginViewController alloc]init];
//        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:vc];
//        [self presentViewController:nav animated:YES completion:nil];
    }
    item.badgeValue=nil;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

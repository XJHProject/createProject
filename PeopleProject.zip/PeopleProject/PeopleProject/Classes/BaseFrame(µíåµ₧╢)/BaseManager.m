//
//  BaseManager.m
//  PeopleProject
//
//  Created by 熊进辉 on 2018/2/22.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import "BaseManager.h"
#import "LoginViewController.h"


#define  APP_DEL (AppDelegate *)[UIApplication sharedApplication].delegate


@implementation BaseManager
+(instancetype)singleton{
    static BaseManager * manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[self alloc]init];
    });
    return manager;
}

-(BaseTabBarController *)setRootControllerWithIndex:(NSInteger const)index{
    BaseTabBarController * tabBarVC = [[BaseTabBarController alloc]init];
    AppDelegate * appDel = APP_DEL;
    appDel.window.rootViewController = tabBarVC;
    tabBarVC.selectedIndex = index;
    [appDel.window makeKeyAndVisible];

    return tabBarVC;
}
-(void)setRootToLoginViewController{
    LoginViewController * vc = [[LoginViewController alloc]init];
    AppDelegate * appDel = APP_DEL;
    UINavigationController * nav=[[UINavigationController alloc]initWithRootViewController:vc];
    appDel.window.rootViewController = nav;
    [appDel.window makeKeyAndVisible];
}
@end

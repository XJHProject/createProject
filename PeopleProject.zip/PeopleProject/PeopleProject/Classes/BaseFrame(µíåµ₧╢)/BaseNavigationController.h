//
//  BaseNavigationController.h
//  PeopleProject
//
//  Created by 熊进辉 on 2018/2/22.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseNavigationController : UINavigationController
@property (nonatomic, nullable, readonly) UIGestureRecognizer * fullInteractivePopGestureRecognizer;
@end

//
//  BaseViewController.m
//  PeopleProject
//
//  Created by 熊进辉 on 2018/2/22.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()
@property (nonatomic, strong) UILabel * titleLbl;//标题
@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];

}
-(void)setControllerTitle:(NSString *)title{
    self.titleLbl = [[UILabel alloc]init];
    self.titleLbl.textColor = [UIColor whiteColor];
    self.titleLbl.font = [UIFont systemFontOfSize:18];
    self.titleLbl.text=title;
    [self.titleLbl sizeToFit];
    self.navigationItem.titleView = self.titleLbl;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

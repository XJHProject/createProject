//
//  BaseNavigationController.m
//  PeopleProject
//
//  Created by 熊进辉 on 2018/2/22.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import "BaseNavigationController.h"

@interface BaseNavigationController ()<UINavigationControllerDelegate,UIGestureRecognizerDelegate>
@property (nonatomic, weak) id popDelegate;
@property (nonatomic, nullable, readwrite) UIGestureRecognizer * fullInteractivePopGestureRecognizer;


@end

@implementation BaseNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.popDelegate = self.interactivePopGestureRecognizer.delegate;
    self.delegate = self;
    //
    UINavigationBar * bar =[UINavigationBar appearance];
    [bar setBarStyle:(UIBarStyleBlack)];
    bar.barTintColor = [UIColor blueColor];
    [bar setTitleTextAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:18],NSForegroundColorAttributeName:[UIColor redColor]}];
    //
    [self setNeedsStatusBarAppearanceUpdate];
    [self preferredStatusBarStyle];
    //实现右滑pop
    //interactivePopGestureRecognizer:侧滑返回手势
    //关闭系统侧滑手势
    self.interactivePopGestureRecognizer.enabled=NO;
    //侧滑返回所在的view
    UIView * view  = self.interactivePopGestureRecognizer.view;
    //侧滑返回的target
    id target = self.interactivePopGestureRecognizer.delegate;
    //侧滑返回的action
    SEL action = NSSelectorFromString(@"handleNavigationTransition:");
    //创建全屏侧滑手势识别器
    self.fullInteractivePopGestureRecognizer = [[UIPanGestureRecognizer alloc]initWithTarget:target action:action];
    self.fullInteractivePopGestureRecognizer.delaysTouchesBegan=YES;
    self.fullInteractivePopGestureRecognizer.delegate=self;
    [view addGestureRecognizer:self.fullInteractivePopGestureRecognizer];
    
}
-(id<UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController animationControllerForOperation:(UINavigationControllerOperation)operation fromViewController:(UIViewController *)fromVC toViewController:(UIViewController *)toVC{
    
    return nil;
}
-(void)navigationController:(UINavigationController *)navigationController interactionControllerForAnimationController:(nonnull id<UIViewControllerAnimatedTransitioning>)animationController{
    
}
//手势是否充许滑动后pop
-(BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    ///左滑时可能与UITableView左滑删除手势产生冲突
    CGPoint translation = [(UIPanGestureRecognizer *)gestureRecognizer translationInView:gestureRecognizer.view];
    if (translation.x<=0) {
        return NO;
    }
    MYLog(@"滑动中。。。 ");
    //根视图控制器不响应手势
    return ([self.viewControllers count] ==1)?NO:YES;
}
-(void)navigationController:(UINavigationController *)navigationController didShowViewController:(UIViewController *)viewController animated:(BOOL)animated{
    if (viewController == self.viewControllers[0]) {
        self.interactivePopGestureRecognizer.delegate = self.popDelegate;
    }else{
        self.interactivePopGestureRecognizer.delegate = nil;
    }
}
-(void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated{
    if (self.childViewControllers.count) {
        viewController.hidesBottomBarWhenPushed=YES;
        UIButton *backBtn=[UIButton buttonWithType:(UIButtonTypeCustom)];
        backBtn.frame = CGRectMake(0, 0, 40, 40);
        [backBtn setImage:[UIImage imageNamed:@"icon_back_normal"] forState:(UIControlStateNormal)];
        [backBtn setImage:[UIImage imageNamed:@"icon_back_pressed"] forState:(UIControlStateHighlighted)];
        [backBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 30)];
        [backBtn addTarget:self action:@selector(popToPre) forControlEvents:(UIControlEventTouchUpInside)];
        UIBarButtonItem *leftItem=[[UIBarButtonItem alloc]initWithCustomView:backBtn];
        viewController.navigationItem.leftBarButtonItem=leftItem;
        //
        viewController.hidesBottomBarWhenPushed = YES;
//        UIBarButtonItem * leftItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"icon_back_normal"] style:(UIBarButtonItemStylePlain) target:self action:@selector(popToPre)];
//        UIBarButtonItem * fixItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:(UIBarButtonSystemItemFixedSpace) target:nil action:nil];
//        fixItem.width=-0;
//        self.navigationItem.leftBarButtonItems=@[fixItem,leftItem];
    }
    [super pushViewController:viewController animated:animated];
}
-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}
-(UIStatusBarAnimation)preferredStatusBarUpdateAnimation{
    return UIStatusBarAnimationFade;
}
-(void)popToPre{
    [self popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  GlobalDefine.m
//  PeopleProject
//
//  Created by 熊进辉 on 2018/2/23.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import "GlobalDefine.h"

@implementation GlobalDefine

@end

//
//  GlobalDefine.h
//  PeopleProject
//
//  Created by 熊进辉 on 2018/2/23.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import <Foundation/Foundation.h>

//日志打印
#ifdef DEBUG

#define MYLog(fmt,...) NSLog((@"%s:" fmt),__FUNCTION__,##__VA_ARGS__)

#else

#define MYLog(...)

#endif

//屏幕宽高
#define SCREEN_W [UIScreen mainScreen].bounds.size.width
#define SCREEN_H [UIScreen mainScreen].bounds.size.height
//RGB
#define RGB(r,g,b) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1.0]
#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1.0-a]
//字体
#define Font(x) UIFont systemFontOfSize:x]

@interface GlobalDefine : NSObject

@end

//
//  BaseDataManager.h
//  PeopleProject
//
//  Created by 熊进辉 on 2018/2/23.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import <Foundation/Foundation.h>

//些单例类用于全局的属性管理
@interface BaseDataManager : NSObject
+(instancetype)singleton;

@property(nonatomic , assign) NSUInteger selectIndex;//记录当前要显示的tabBar的selectIndex
@property(nonatomic , assign) BOOL loginState;//当前的登录状态
@end

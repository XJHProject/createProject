//
//  BaseDataManager.m
//  PeopleProject
//
//  Created by 熊进辉 on 2018/2/23.
//  Copyright © 2018年 熊进辉. All rights reserved.
//

#import "BaseDataManager.h"

@implementation BaseDataManager

+(instancetype)singleton{
    static BaseDataManager * manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[self alloc]init];
    });
    return manager;
}

@end
